# Please contribute!
You can really make a difference by:
- [Making an issue](https://help.github.com/articles/creating-an-issue/). A well described issue helps a lot.
- [Making a pull request](https://services.github.com/on-demand/github-cli/open-pull-request-github) when you see the error in code.
