import csv

with open('articles.csv', mode='r') as infile:
    reader = csv.reader(infile)
    with open('articles_new.csv', mode='w') as outfile:
        writer = csv.writer(outfile)
        mydict = {rows[0]:rows[5] for rows in reader}