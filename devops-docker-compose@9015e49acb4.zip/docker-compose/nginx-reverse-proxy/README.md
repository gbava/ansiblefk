## Instructions

- Clone the repository: `git clone -b docker-compose https://bitbucket.forwardkeys.com/scm/for/devops.git`

- `cd devops/docker-compose/nginx-reverse-proxy`


- Create the logs directory: `mkdir log`

- Copy the SSL certificates to the `certs` folder (forwardkeys.ca-bundle and forwardkeys-2019.key)

- To start the container run: `docker-compose up -d` (The -d will make it run in the background)

- To restart the container run: `docker-compose down && docker-compose up -d`

- To read the log run: `docker-compose logs -f`
