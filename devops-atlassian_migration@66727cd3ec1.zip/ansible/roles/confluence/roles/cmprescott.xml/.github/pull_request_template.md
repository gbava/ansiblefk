Thank you for your effort to improve this module!

The xml module is upstream now and ships with Ansible v2.4 which is to be released in mid-September:
https://github.com/ansible/ansible/blob/devel/docs/docsite/rst/roadmap/ROADMAP_2_4.rst

Please try running ansible from source:
http://docs.ansible.com/ansible/intro_installation.html#running-from-source
and see if the change you wanted to make is already done.

Note that you'll need version of lxml>=2.3.0.

If you still want to make a pull request, please check if something similar already exists upstream:
https://github.com/ansible/ansible/pulls
and create it there if it's not already created.
